<?php
session_start();
include('includes/config.php');

if (!isset($_GET['booking_id'])) {
    echo "<script>alert('Invalid Booking!'); window.location='index.php';</script>";
    exit;
}

$booking_id = $_GET['booking_id'];

// Fetch booking details
$sql = "SELECT b.*, p.PackageName, p.PackagePrice, p.PackageLocation 
        FROM tblbookings b
        JOIN tbltourpackages p ON b.PackageId = p.PackageId
        WHERE b.BookingId = :booking_id";
$query = $dbh->prepare($sql);
$query->bindParam(':booking_id', $booking_id, PDO::PARAM_INT);
$query->execute();
$booking = $query->fetch(PDO::FETCH_OBJ);

if (!$booking) {
    echo "<script>alert('Booking not found!'); window.location='index.php';</script>";
    exit;
}

// Pricing Calculation
$base_price = $booking->PackagePrice / 10; // Base price per person
$num_persons = $booking->NumPersons;
$total_price = $num_persons * $base_price;

$discount_percentage = 0;
if ($num_persons >= 15) {
    $discount_percentage = floor(($num_persons - 10) / 5) * 2;
}

// Additional discount for specific numbers
$mid_values = [13 => 1, 18 => 3, 23 => 5, 28 => 7, 33 => 9, 38 => 11, 43 => 13, 48 => 15, 53 => 17, 58 => 19];
if (isset($mid_values[$num_persons])) {
    $discount_percentage = $mid_values[$num_persons];
}

// Calculate Discount
$discount_amount = ($total_price * $discount_percentage) / 100;
$final_price = $total_price - $discount_amount;

// Store invoice in database
$insert_sql = "INSERT INTO tblinvoices (BookingId, CustomerName, Email, Mobile, PackageName, PackageLocation, 
                                        NumPersons, StartDate, EndDate, TourType, BasePrice, DiscountPercentage, 
                                        DiscountAmount, FinalAmount)
               VALUES (:booking_id, :customer_name, :email, :mobile, :package_name, :package_location, 
                       :num_persons, :start_date, :end_date, :tour_type, :base_price, :discount_percentage, 
                       :discount_amount, :final_price)";
$insert_query = $dbh->prepare($insert_sql);
$insert_query->bindParam(':booking_id', $booking_id, PDO::PARAM_INT);
$insert_query->bindParam(':customer_name', $booking->Name, PDO::PARAM_STR);
$insert_query->bindParam(':email', $booking->Email, PDO::PARAM_STR);
$insert_query->bindParam(':mobile', $booking->Mobile, PDO::PARAM_STR);
$insert_query->bindParam(':package_name', $booking->PackageName, PDO::PARAM_STR);
$insert_query->bindParam(':package_location', $booking->PackageLocation, PDO::PARAM_STR);
$insert_query->bindParam(':num_persons', $num_persons, PDO::PARAM_INT);
$insert_query->bindParam(':start_date', $booking->StartDate, PDO::PARAM_STR);
$insert_query->bindParam(':end_date', $booking->EndDate, PDO::PARAM_STR);
$insert_query->bindParam(':tour_type', $booking->TourType, PDO::PARAM_STR);
$insert_query->bindParam(':base_price', $base_price, PDO::PARAM_STR);
$insert_query->bindParam(':discount_percentage', $discount_percentage, PDO::PARAM_STR);
$insert_query->bindParam(':discount_amount', $discount_amount, PDO::PARAM_STR);
$insert_query->bindParam(':final_price', $final_price, PDO::PARAM_STR);
$insert_query->execute();
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Booking Invoice</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4cc9f0;
            --success-color: #4caf50;
            --warning-color: #ff9800;
            --danger-color: #f44336;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --gray-color: #6c757d;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7ff;
            color: var(--dark-color);
            line-height: 1.6;
        }
        
        .invoice-wrapper {
            max-width: 900px;
            margin: 2rem auto;
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            position: relative;
        }
        
        .invoice-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .invoice-header::before {
            content: "";
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
        
        .invoice-header::after {
            content: "";
            position: absolute;
            bottom: -80px;
            left: -80px;
            width: 250px;
            height: 250px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
        
        .invoice-title {
            font-size: 2.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 1;
        }
        
        .invoice-subtitle {
            font-size: 1rem;
            opacity: 0.9;
            position: relative;
            z-index: 1;
        }
        
        .invoice-body {
            padding: 2rem;
        }
        
        .invoice-info {
            display: flex;
            flex-wrap: wrap;
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        .info-section {
            flex: 1;
            min-width: 250px;
        }
        
        .info-section h3 {
            font-size: 1.2rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--light-color);
        }
        
        .info-item {
            display: flex;
            margin-bottom: 0.8rem;
        }
        
        .info-label {
            font-weight: 500;
            color: var(--gray-color);
            min-width: 120px;
        }
        
        .info-value {
            font-weight: 500;
        }
        
        .price-summary {
            background: var(--light-color);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .price-row {
            display: flex;
            justify-content: space-between;
            padding: 0.8rem 0;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .price-row:last-child {
            border-bottom: none;
        }
        
        .price-label {
            font-weight: 500;
        }
        
        .price-value {
            font-weight: 600;
        }
        
        .total-row {
            font-size: 1.2rem;
            color: var(--primary-color);
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 2px dashed var(--gray-color);
        }
        
        .discount-row {
            color: var(--success-color);
        }
        
        .invoice-actions {
            display: flex;
            justify-content: space-between;
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            font-weight: 500;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            font-size: 1rem;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .btn-secondary {
            background: white;
            color: var(--primary-color);
            border: 1px solid var(--primary-color);
        }
        
        .btn-secondary:hover {
            background: var(--light-color);
            transform: translateY(-2px);
        }
        
        .invoice-footer {
            text-align: center;
            padding: 1.5rem;
            background: var(--light-color);
            color: var(--gray-color);
            font-size: 0.9rem;
        }
        
        .thank-you {
            font-weight: 500;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        
        .company-info {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-top: 0.5rem;
        }
        
        .company-info a {
            color: var(--gray-color);
            transition: color 0.3s ease;
        }
        
        .company-info a:hover {
            color: var(--primary-color);
        }
        
        @media (max-width: 768px) {
            .invoice-wrapper {
                margin: 1rem;
                border-radius: 12px;
            }
            
            .invoice-info {
                flex-direction: column;
                gap: 1.5rem;
            }
            
            .invoice-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
            }
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<div class="invoice-wrapper">
    <div class="invoice-header">
        <h1 class="invoice-title">Booking Confirmation</h1>
        <p class="invoice-subtitle">Your adventure starts here!</p>
    </div>
    
    <div class="invoice-body">
        <div class="invoice-info">
            <div class="info-section">
                <h3>Booking Details</h3>
                <div class="info-item">
                    <span class="info-label">Booking ID:</span>
                    <span class="info-value"><?= $booking_id; ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Package Name:</span>
                    <span class="info-value"><?= $booking->PackageName; ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Location:</span>
                    <span class="info-value"><?= $booking->PackageLocation; ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Tour Type:</span>
                    <span class="info-value"><?= $booking->TourType; ?></span>
                </div>
            </div>
            
            <div class="info-section">
                <h3>Travel Dates</h3>
                <div class="info-item">
                    <span class="info-label">Start Date:</span>
                    <span class="info-value"><?= $booking->StartDate; ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">End Date:</span>
                    <span class="info-value"><?= $booking->EndDate; ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Travelers:</span>
                    <span class="info-value"><?= $num_persons; ?> person(s)</span>
                </div>
            </div>
            
            <div class="info-section">
                <h3>Customer Information</h3>
                <div class="info-item">
                    <span class="info-label">Name:</span>
                    <span class="info-value"><?= $booking->Name; ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Email:</span>
                    <span class="info-value"><?= $booking->Email; ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Mobile:</span>
                    <span class="info-value"><?= $booking->Mobile; ?></span>
                </div>
            </div>
        </div>
        
        <div class="price-summary">
            <h3>Price Summary</h3>
            <div class="price-row">
                <span class="price-label">Base Price (per person):</span>
                <span class="price-value">Rs <?= number_format($base_price, 2); ?></span>
            </div>
            <div class="price-row">
                <span class="price-label">Number of Persons:</span>
                <span class="price-value"><?= $num_persons; ?></span>
            </div>
            <div class="price-row">
                <span class="price-label">Subtotal:</span>
                <span class="price-value">Rs <?= number_format($total_price, 2); ?></span>
            </div>
            <div class="price-row discount-row">
                <span class="price-label">Discount (<?= $discount_percentage; ?>%):</span>
                <span class="price-value">- Rs <?= number_format($discount_amount, 2); ?></span>
            </div>
            <div class="price-row total-row">
                <span class="price-label">Total Amount:</span>
                <span class="price-value">Rs <?= number_format($final_price, 2); ?></span>
            </div>
        </div>
        
        <div class="invoice-actions">
            <button class="btn btn-secondary" onclick="window.history.back();">
                <i class="fas fa-arrow-left"></i> Back
            </button>
            <button class="btn btn-primary" id="confirm-button">
                <i class="fas fa-check-circle"></i> Confirm Booking
            </button>
        </div>
    </div>
    
    <div class="invoice-footer">
        <p class="thank-you">Thank you for choosing our travel services!</p>
        <p>Your booking has been processed successfully.</p>
        <div class="company-info">
            <a href="#"><i class="fas fa-phone"></i> +1 234 567 890</a>
            <a href="#"><i class="fas fa-envelope"></i> support@travelcompany.com</a>
            <a href="#"><i class="fas fa-globe"></i> www.travelcompany.com</a>
        </div>
    </div>
</div>

<script>
    document.getElementById('confirm-button').addEventListener('click', function() {
        Swal.fire({
            title: 'Booking Confirmed!',
            text: 'Your tour package has been successfully booked.',
            icon: 'success',
            confirmButtonColor: '#4361ee',
            confirmButtonText: 'Continue',
            allowOutsideClick: false
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'home.php';
            }
        });
    });
</script>

</body>
</html>