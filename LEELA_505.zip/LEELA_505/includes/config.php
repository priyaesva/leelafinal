<?php
// Database configuration
$host = "localhost";  // Change if necessary
$dbname = "suma";  // Replace with actual database name
$username = "root";  // Replace with actual username
$password = "";  // Replace with actual password

try {
    $dbh = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ
    ]);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
